<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta property="og:title" content="Jasa Service Raket Terbaik | Bengkel Sport Kreatif">
    <meta property="og:description" content="Jasa layanan profesional untuk perbaikan dan perawatan raket badminton dan tenis. Layanan kustomisasi, ganti grip, dan penyetelan raket. Hubungi kami untuk layanan berkualitas.">
    <meta property="og:type" content="website">
    <meta property="og:url" content="https://www.bskreatif.com/jasa-service-raket">
    <meta property="og:image" content="https://www.bskreatif.test/img/gambar/slide1m.jpg">
    <meta name="description" content="Jasa profesional untuk perbaikan dan perawatan raket badminton dan tenis. Layanan kami meliputi penyetelan, ganti grip, perbaikan kerusakan, dan kustomisasi raket agar sesuai dengan preferensi Anda. Hubungi kami untuk layanan handal dan berkualitas.">
    <meta name="robots" content="index, follow">
    <meta name="keywords" content="jasa raket, badminton, tenis, perbaikan raket, ganti grip, penyetelan raket">
    <link rel="canonical" href="https://www.bskreatif.com/jasa-service-raket">

    <link rel="icon" type="image/x-icon" href="{{ asset('favicon.png') }}">


    <title>Jasa Service Raket Terbaik | {{ $title }}</title>

    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,300;0,400;0,700;1,700&display=swap" rel="stylesheet" />
    <link href="{{ asset('css/bootstrap.min.css') }}" rel="stylesheet">

    <link rel="stylesheet" href="{{ asset('vendor/fontawesome-free/css/all.min.css') }}" />
    <link rel="stylesheet" href="{{ asset('css/style.css') }}">
</head>

<body>

    @include('partials.navbar')

    @yield('content')

<button type="button" class="btn btn-danger btn-floating btn-sm" id="btn-back-to-top">
    <i class="fas fa-angle-up"></i>
</button>

<a href="https://api.whatsapp.com/send?phone=6285266528221&text=Nama%3A%0ANomor%20Telepon%3A%0AJenis%20Layanan%3A%0ADetail%20Pesanan%3A%0AWaktu%20yang%20diinginkan%3A" target="_blank" class="btn text-green btn-sm rounded-circle" id="whatsapp">
    <i class="fab fa-whatsapp text-light fa-2x text-center"></i>
</a >
    <script src="{{ asset('js/bootstrap.bundle.min.js') }}"></script>
    <script src="{{ asset('js/script.js') }}"></script>
</body>

</html>